package slideshow;

public class Photo {
    private int id;
    private char or;
    private String [] tags;
//    private int [] commonIdx;
 //   private int []


    public Photo(int id, char or, String[] tags) {
        this.id = id;
        this.or = or;
        this.tags = tags;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public char getOr() {
        return or;
    }

    public void setOr(char or) {
        this.or = or;
    }

    public String[] getTags() {
        return tags;
    }

    public void setTags(String[] tags) {
        this.tags = tags;
    }

    // interest number when paired with all others in 1000 photo grid.

    // methods to get intersec, not el.
}
